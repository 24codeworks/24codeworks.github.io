import"./SocialShare.astro_astro_type_script_index_1_lang.C8BIuqsA.js";
