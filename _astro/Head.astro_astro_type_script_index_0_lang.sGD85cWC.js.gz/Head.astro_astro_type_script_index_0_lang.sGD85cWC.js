import"./MainLayout.astro_astro_type_script_index_0_lang.e1kiV1qb.js";
